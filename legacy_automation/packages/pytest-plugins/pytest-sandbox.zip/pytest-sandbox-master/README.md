pytest-sandbox
==============
[![Build Status](https://travis-ci.org/manojklm/pytest-sandbox.svg?branch=master)](https://travis-ci.org/manojklm/pytest-sandbox)
Creates a sandbox temp directory and executes tests inside it
